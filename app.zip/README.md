# IslandScope V1.3.5 Source

Rootless Theos project; build with `make clean package`. Not compiled or device-tested here.

## V1.3.5 fix
The green 导出日志 action stages a timestamped copy of the current `events.log` in `NSTemporaryDirectory()` (instead of Documents/IslandScopeExports), then opens `UIDocumentPickerViewController initForExportingURLs:asCopy:` for a native Save to Files workflow. No `UIActivityViewController` / AirDrop share sheet. Errors are displayed if staging fails.

The original read-only SpringBoard monitoring hooks, automatic log recording and 2 MB rotation are unchanged. Source, tweak log tags, UI, Info.plist and DEB version are synchronized to 1.3.5.

Logs: `/var/mobile/Library/Logs/IslandScope/`. Minimum iOS 16.0; cross-version compatibility is not verified. Install the resulting DEB and respring.
