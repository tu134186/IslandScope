#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <os/lock.h>
#import <dispatch/dispatch.h>

// IslandScope V1.3.5: observation only; no view changes or forced layouts.
// Logging to unified system log. Collect using log stream or a SpringBoard syslog tool.
static os_unfair_lock gLock = OS_UNFAIR_LOCK_INIT;
static NSMutableDictionary<NSString *, NSNumber *> *gLast;
static NSUInteger gEvents = 0;
static const NSUInteger kMaxEvents = 12000; // per SpringBoard lifetime
static dispatch_queue_t gFileQueue;
static NSString * const kLogDirectory = @"/var/mobile/Library/Logs/IslandScope";
static NSString * const kLogFile = @"/var/mobile/Library/Logs/IslandScope/events.log";
static NSString * const kConfigFile = @"/var/mobile/Library/Logs/IslandScope/config.plist";
static const unsigned long long kMaxLogBytes = 2ULL * 1024ULL * 1024ULL;

// All disk work is asynchronous; never write files inside SpringBoard layout hooks.
static void ISWriteLine(NSString *line) {
    if (!gFileQueue || !line) return;
    dispatch_async(gFileQueue, ^{
        @autoreleasepool {
            NSFileManager *fm = [NSFileManager defaultManager];
            NSError *error = nil;
            if (![fm createDirectoryAtPath:kLogDirectory withIntermediateDirectories:YES attributes:nil error:&error]) return;
            NSDictionary *attributes = [fm attributesOfItemAtPath:kLogFile error:nil];
            unsigned long long size = [attributes fileSize];
            if (size >= kMaxLogBytes) {
                NSString *old = [kLogDirectory stringByAppendingPathComponent:@"events.previous.log"];
                [fm removeItemAtPath:old error:nil];
                [fm moveItemAtPath:kLogFile toPath:old error:nil];
            }
            NSData *data = [[line stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding];
            if (![fm fileExistsAtPath:kLogFile]) [fm createFileAtPath:kLogFile contents:nil attributes:nil];
            NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:kLogFile];
            if (!handle) return;
            @try { [handle seekToEndOfFile]; [handle writeData:data]; [handle closeFile]; }
            @catch (NSException *exception) { @try { [handle closeFile]; } @catch (NSException *ignored) {} }
        }
    });
}
static void ISReport(NSString *message) {
    NSLog(@"%@", message);
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss.SSS ZZZZ";
    NSString *line = [NSString stringWithFormat:@"%@ %@", [formatter stringFromDate:[NSDate date]], message];
    ISWriteLine(line);
}

static BOOL ISCaptureEnabled(void) {
    static NSTimeInterval lastCheck = 0;
    static BOOL enabled = YES;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    // SpringBoard view hooks run on the main thread; only check configuration once every 3s.
    if (now - lastCheck >= 3.0) {
        lastCheck = now;
        NSDictionary *cfg = [NSDictionary dictionaryWithContentsOfFile:kConfigFile];
        if (cfg[@"enabled"]) enabled = [cfg[@"enabled"] boolValue];
    }
    return enabled;
}
static void ISLog(NSString *kind, id object, NSString *detail) {
    if (!ISCaptureEnabled()) return;
    if (!object) return;
    NSTimeInterval now = [NSDate date].timeIntervalSince1970;
    NSString *key = [NSString stringWithFormat:@"%@:%p", kind, object];
    os_unfair_lock_lock(&gLock);
    if (!gLast) gLast = [NSMutableDictionary new];
    NSTimeInterval previous = [gLast[key] doubleValue];
    BOOL allowed = gEvents < kMaxEvents && (now - previous >= 0.75);
    if (allowed) { gLast[key] = @(now); ++gEvents; }
    // Bound dedup dictionary memory; old entries can be re-created later.
    if (gLast.count > 512) [gLast removeAllObjects];
    os_unfair_lock_unlock(&gLock);
    if (allowed) ISReport([NSString stringWithFormat:@"[IslandScope 1.3.5] %@ class=%@ ptr=%p %@", kind, NSStringFromClass([object class]), object, detail ?: @""]);
}

// Use runtime class existence checks: class names vary between iOS builds.
static void ISDidMove(id self, SEL _cmd, IMP original) {
    ((void (*)(id, SEL))original)(self, _cmd);
    if ([self isKindOfClass:[UIView class]]) {
        UIView *v = (UIView *)self;
        ISLog(@"didMoveToWindow", self, [NSString stringWithFormat:@"window=%p superview=%p", v.window, v.superview]);
    }
}
static void ISLayout(id self, SEL _cmd, IMP original) {
    ((void (*)(id, SEL))original)(self, _cmd);
    if ([self isKindOfClass:[UIView class]]) {
        UIView *v = (UIView *)self;
        ISLog(@"layoutSubviews", self, [NSString stringWithFormat:@"window=%p superview=%p frame=%@", v.window, v.superview, NSStringFromCGRect(v.frame)]);
    }
}
// Fixed class slots avoid IMP <-> void* conversion and dictionary lookups on hot paths.
// Only three classes are observed; never hook UIView globally.
struct ISHookSlot { Class cls; IMP moveOriginal; IMP layoutOriginal; };
static ISHookSlot gSlots[3] = {};
static IMP ISOriginal(id object, SEL selector) {
    for (Class current = object_getClass(object); current; current = class_getSuperclass(current)) {
        for (unsigned int i = 0; i < 3; ++i) {
            if (gSlots[i].cls == current) {
                return selector == @selector(didMoveToWindow) ? gSlots[i].moveOriginal : gSlots[i].layoutOriginal;
            }
        }
    }
    return nullptr;
}
static void ISMoveHook(id self, SEL cmd) {
    IMP original = ISOriginal(self, cmd);
    if (original) ISDidMove(self, cmd, original);
}
static void ISLayoutHook(id self, SEL cmd) {
    IMP original = ISOriginal(self, cmd);
    if (original) ISLayout(self, cmd, original);
}
static void ISHookClass(const char *name, unsigned int slot) {
    Class cls = objc_getClass(name);
    if (!cls || ![cls isSubclassOfClass:[UIView class]]) {
        ISReport([NSString stringWithFormat:@"[IslandScope 1.3.5] unavailable UIView class: %s", name]);
        return;
    }
    gSlots[slot].cls = cls;
    SEL selectors[] = {@selector(didMoveToWindow), @selector(layoutSubviews)};
    IMP hooks[] = {reinterpret_cast<IMP>(&ISMoveHook), reinterpret_cast<IMP>(&ISLayoutHook)};
    for (unsigned int i = 0; i < 2; ++i) {
        Method inherited = class_getInstanceMethod(cls, selectors[i]);
        if (!inherited) continue;
        IMP original = method_getImplementation(inherited);
        if (original == hooks[i]) continue;
        IMP *storage = i == 0 ? &gSlots[slot].moveOriginal : &gSlots[slot].layoutOriginal;
        *storage = original;
        const char *types = method_getTypeEncoding(inherited);
        if (!class_addMethod(cls, selectors[i], hooks[i], types)) {
            // Replace only an implementation defined directly on this class.
            unsigned int count = 0;
            Method *methods = class_copyMethodList(cls, &count);
            Method own = NULL;
            for (unsigned int j = 0; j < count; ++j) {
                if (method_getName(methods[j]) == selectors[i]) { own = methods[j]; break; }
            }
            if (own) *storage = method_setImplementation(own, hooks[i]);
            free(methods);
            if (!own) { *storage = nullptr; continue; }
        }
        ISReport([NSString stringWithFormat:@"[IslandScope 1.3.5] observing %s %s", name, sel_getName(selectors[i])]);
    }
}
__attribute__((constructor)) static void ISStart(void) {
    @autoreleasepool {
        gFileQueue = dispatch_queue_create("com.tu.islandscope.filelog", DISPATCH_QUEUE_SERIAL);
        ISReport([NSString stringWithFormat:@"[IslandScope 1.3.5] loaded (read-only, event cap=%lu, file=%@)", (unsigned long)kMaxEvents, kLogFile]);
        const char *names[] = {"SBSystemApertureContainerView", "SAUIElementView", "SBRecordingIndicatorView"};
        for (NSUInteger i = 0; i < sizeof(names)/sizeof(names[0]); ++i) ISHookClass(names[i], (unsigned int)i);
    }
}
